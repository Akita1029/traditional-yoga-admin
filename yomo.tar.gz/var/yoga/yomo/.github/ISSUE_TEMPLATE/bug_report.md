---
name: Bug report
about: Create a report to help improve the project
title: "[BUG]"
labels: bug
assignees: fanweixiao, venjiang, xiaojian-hong

---

<!--
Please read the CONTRIBUTING.md guidelines to learn on which channels you can
seek for help and ask general questions:
https://github.com/yomorun/yomo/blob/master/CONTRIBUTING.md#where-to-seek-for-help
-->

### Summary

SUMMARY_GOES_HERE

### Steps To Reproduce

1.
2.
3.
4.

### Additional Details & Logs

- Yomo version
- Yomo error logs
- Yomo configuration
- Operating system
