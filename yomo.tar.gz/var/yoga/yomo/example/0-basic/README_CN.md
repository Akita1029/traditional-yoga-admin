# 基本示例

## 先决条件

确保已安装 `task`，见官方[安装文档](https://taskfile.dev/#/installation)

## 查看任务

```sh
task -l
```

## 运行基本示例

```sh
task run
```
