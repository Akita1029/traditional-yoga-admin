import React, { useEffect } from 'react';
import PropTypes from "prop-types";
import { withRouter } from "react-router-dom";
import logoSm from "../../assets/images/logo-sm.png";


//import Components
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';
import RightSidebar from '../../Components/Common/RightSidebar';

//import actions
import {
    changeLayout,
    changeSidebarTheme,
    changeLayoutMode,
    changeLayoutWidth,
    changeLayoutPosition,
    changeTopbarTheme,
    changeLeftsidebarSizeType,
    changeLeftsidebarViewType
} from "../../store/actions";

//redux
import { useSelector, useDispatch } from "react-redux";


const Layout = (props) => {
   
    const dispatch = useDispatch();
    const {
        layoutType,
        leftSidebarType,
        layoutModeType,
        layoutWidthType,
        layoutPositionType,
        topbarThemeType,
        leftsidbarSizeType,
        leftSidebarViewType
    } = useSelector(state => ({
        layoutType: state.Layout.layoutType,
        leftSidebarType: state.Layout.leftSidebarType,
        layoutModeType: state.Layout.layoutModeType,
        layoutWidthType: state.Layout.layoutWidthType,
        layoutPositionType: state.Layout.layoutPositionType,
        topbarThemeType: state.Layout.topbarThemeType,
        leftsidbarSizeType: state.Layout.leftsidbarSizeType,
        leftSidebarViewType: state.Layout.leftSidebarViewType,
    }));

    /*
    layout settings
    */
    useEffect(() => {
        if (
            layoutType ||
            leftSidebarType ||
            layoutModeType ||
            layoutWidthType ||
            layoutPositionType ||
            topbarThemeType ||
            leftsidbarSizeType ||
            leftSidebarViewType) {
            dispatch(changeLeftsidebarViewType(leftSidebarViewType));
            dispatch(changeLeftsidebarSizeType(leftsidbarSizeType));
            dispatch(changeSidebarTheme(leftSidebarType));
            dispatch(changeLayoutMode(layoutModeType));
            dispatch(changeLayoutWidth(layoutWidthType));
            dispatch(changeLayoutPosition(layoutPositionType));
            dispatch(changeTopbarTheme(topbarThemeType));
            dispatch(changeLayout(layoutType));
        }
    }, [layoutType,
        leftSidebarType,
        layoutModeType,
        layoutWidthType,
        layoutPositionType,
        topbarThemeType,
        leftsidbarSizeType,
        leftSidebarViewType,
        dispatch]);
    /*
    call dark/light mode
    */
    const onChangeLayoutMode = (value) => {
        if (changeLayoutMode) {
            dispatch(changeLayoutMode(value));
        }
    };
    // var navbarMenuHTML = document.querySelector('.navbar-menu');
    // console.log("navbarMenuHTML", navbarMenuHTML)
    //Horizontal Menu Genrate
    const updateHorizontalMenus = () => {
        var horizontalMenuSplit = 6;
        var splitMenu = horizontalMenuSplit;
        var extraMenuName = "More";
        var menuData = document.querySelectorAll("ul.navbar-nav > li.nav-item");
        var newMenus = '';
        var splitItem = '';

        menuData.forEach(function (item, index) {
            if (index + 1 === splitMenu) {
                splitItem = item;
            }
            if (index + 1 > splitMenu) {
                newMenus += item.outerHTML;
                item.remove();
            }

            if (index + 1 === menuData.length) {
                splitItem.insertAdjacentHTML("afterend", '<li class="nav-item">' +
                    '<a class="nav-link" href="#sidebarMore" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarMore">' +
                    '<i class="ri-briefcase-2-line"></i> ' + extraMenuName + '' +
                    '</a>' +
                    '<div class="collapse menu-dropdown" id="sidebarMore">' +
                    '<ul class="nav nav-sm flex-column">' + newMenus + '</ul></div></li>');
            }
        });
    };

    function initTwoColumnActiveMenu() {
        // two column sidebar active js
        const currentPath = props.location.pathname == "/" ? "index" : props.location.pathname.substring(1);


        if (currentPath) {
            // navbar-nav
            // const a = document.getElementById("navbar-nav").querySelector('[href="' + currentPath + '"]');
            const a = document.getElementById("navbar-nav").querySelector('[href="/dashboard-analytics"]');

            if (a) {
                a.classList.add("active");
                var parentCollapseDiv = a.closest('.menu-dropdown');
                if (parentCollapseDiv && parentCollapseDiv.parentElement.closest('.menu-dropdown')) {
                    parentCollapseDiv.classList.add("show");
                    parentCollapseDiv.parentElement.children[0].classList.add("active");
                    parentCollapseDiv.parentElement.closest('.menu-dropdown').parentElement.classList.add("twocolumn-item-show");

                    var menuId = parentCollapseDiv.parentElement.closest('.menu-dropdown').getAttribute("id");
                    if (document.getElementById("two-column-menu").querySelector('[href="#' + menuId + '"]'))
                        document.getElementById("two-column-menu").querySelector('[href="#' + menuId + '"]').classList.add("active");
                } else {
                    a.closest('.menu-dropdown').parentElement.classList.add("twocolumn-item-show");
                    var menuId = parentCollapseDiv.getAttribute("id");
                    if (document.getElementById("two-column-menu").querySelector('[href="#' + menuId + '"]'))
                        document.getElementById("two-column-menu").querySelector('[href="#' + menuId + '"]').classList.add("active");
                }
            }
        }
    }

    function twoColumnMenuGenerate() {
        var ul = document.createElement("ul");
        ul.innerHTML = '<a href="#" class="logo"><img src=' + logoSm + ' alt="" height="22"></a>';
        document.getElementById("navbar-nav").querySelectorAll(".menu-link").forEach(function (item) {
            ul.className = "twocolumn-iconview";
            var li = document.createElement("li");
            var a = item; //document.createElement("a");
            a.querySelectorAll('span').forEach(function (element) {
                element.classList.add('d-none');
            });

            // // need to remove below code
            if (item.parentElement.classList.contains("twocolumn-item-show")) {
                item.classList.add('active');
            }
            li.appendChild(a);
            ul.appendChild(li);
            if (a.classList.contains("nav-link")) {
                a.classList.replace("nav-link", "nav-icon");
            }

            a.classList.remove("collapsed", "menu-link");
        });
        var currentPath = window.location.pathname === "/" ? "index" : window.location.pathname.substring(1);
        if (currentPath) {
            // navbar-nav
            var a = document.getElementById("navbar-nav").querySelector('[href="' + currentPath + '"]');

            if (a) {
                alert();
                var parentCollapseDiv = a.closest('.collapse.menu-dropdown');
                if (parentCollapseDiv) {
                    parentCollapseDiv.classList.add("show");
                    parentCollapseDiv.parentElement.children[0].classList.add("active");
                    parentCollapseDiv.parentElement.children[0].setAttribute("aria-expanded", "true");
                    if (parentCollapseDiv.parentElement.closest('.collapse.menu-dropdown')) {
                        parentCollapseDiv.parentElement.closest(".collapse").classList.add("show");
                        if (parentCollapseDiv.parentElement.closest(".collapse").previousElementSibling)
                            parentCollapseDiv.parentElement.closest(".collapse").previousElementSibling.classList.add("active");
                    }
                }
            }
        }
        // add all sidebar menu icons
        document.getElementById("two-column-menu").innerHTML = ul.outerHTML;

        // show submenu on sidebar menu click
        document.querySelector("#two-column-menu ul").querySelectorAll("li a").forEach(function (element) {
            element.addEventListener("click", function (e) {
                if (!(window.location.pathname === '/' + element.getAttribute("href") && !element.getAttribute("data-bs-toggle")))
                    if (document.body.classList.contains("twocolumn-panel")) document.body.classList.remove("twocolumn-panel");
                document.getElementById("navbar-nav").classList.remove('twocolumn-nav-hide');
                document.querySelector(".hamburger-icon").classList.remove('open');
                if (e.target && (e.target.matches("a.nav-icon") || e.target.matches("i"))) {

                    if (document.querySelector('#two-column-menu ul .nav-icon.active') !== null)
                        document.querySelector('#two-column-menu ul .nav-icon.active').classList.remove('active');
                    (e.target.matches("i")) ? e.target.closest('a').classList.add("active") : e.target.classList.add("active");

                    var twoColumnItem = document.getElementsByClassName('twocolumn-item-show');

                    if (twoColumnItem.length > 0) twoColumnItem[0].classList.remove('twocolumn-item-show');

                    var currentMenu = (e.target.matches("i")) ? e.target.closest('a') : e.target;
                    var childMenusId = currentMenu.getAttribute('href').slice(1);
                    document.getElementById(childMenusId).parentElement.classList.add('twocolumn-item-show');
                }
            });

            // add active class to the sidebar menu icon who has direct link
            if (window.location.pathname === '/' + element.getAttribute("href") && !element.getAttribute("data-bs-toggle")) {
                element.classList.add('active');
                document.getElementById("navbar-nav").classList.add('twocolumn-nav-hide');
                document.querySelector(".hamburger-icon").classList.add('open');
            }
        });

        var currentLayout = document.documentElement.getAttribute("data-layout");
        // if (currentLayout !== "horizontal") {
        //     var simpleBar = SimpleBar(document.getElementById("navbar-nav"));
        //     if (simpleBar)
        //         simpleBar.getContentElement();

        //     var simpleBar1 = SimpleBar(document.getElementsByClassName("twocolumn-iconview")[0]);
        //     if (simpleBar1)
        //         simpleBar1.getContentElement();
        // }
    }

    //Horizontal Menu
    if (document.documentElement.getAttribute("data-layout") === 'horizontal') {
        updateHorizontalMenus();
    }

    // if (document.documentElement.getAttribute("data-layout") === 'twocolumn') {
    //     // console.log("document.querySelector('.navbar-menu')", document.querySelector('.navbar-menu'))
    //     // document.querySelector('.navbar-menu').innerHTML = navbarMenuHTML;
    //     initTwoColumnActiveMenu();
    //     twoColumnMenuGenerate();
    // }


    return (
        <React.Fragment>
            <div id="layout-wrapper">
                <Header
                    layoutModeType={layoutModeType}
                    onChangeLayoutMode={onChangeLayoutMode} />
                <Sidebar layoutType={layoutType} />
                <div className="main-content">{props.children}
                    <Footer />
                </div>
            </div>
            <RightSidebar />
        </React.Fragment>

    );
};

Layout.propTypes = {
    children: PropTypes.object,
};

export default withRouter(Layout);