import React from 'react';

const Layout = () => {
    return (
        <div>
            horizontal layout
        </div>
    );
};

export default Layout;