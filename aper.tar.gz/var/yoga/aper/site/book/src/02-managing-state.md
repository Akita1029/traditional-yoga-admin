# Managing State

In this section, we will look at the core `aper` crate
and how it represents data.