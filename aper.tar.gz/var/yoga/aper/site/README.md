# Aper Website Resources

The Aper book, website, and doctests repositories.
