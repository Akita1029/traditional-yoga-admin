Examples use [Stateroom](https://github.com/drifting-in-space/stateroom), which builds and serves both the client and server components of the code.

Install Stateroom by running `cargo install stateroom`, and then run `stateroom dev` in the base of any of the examples.
